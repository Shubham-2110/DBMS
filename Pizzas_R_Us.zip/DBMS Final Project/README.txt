

-->The src folder under the Pizzeria folder contains the .class files.
-->The bin folder under the Pizzeria folder contains the .java files.

