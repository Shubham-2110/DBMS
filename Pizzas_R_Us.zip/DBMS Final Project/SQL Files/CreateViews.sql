use group16dbmsnew;

-- View No. 1

create view ToppingPopularity as
select t1.ToppingName, sum(
case 
when t2.ToppingExtraYesOrNo = true
then 2
else 1
end
) as toppingcount
from toppingbridge as t2
join topping as t1
on t1.ToppingID = t2.ToppingBridgeToppingID
group by t2.ToppingBridgeToppingID
order by toppingcount desc;

select * from ToppingPopularity;

-- View No. 2

CREATE VIEW ProfitByPizza AS
select p1.PizzaSizeType, p1.PizzaCrustType, (sum(p1.PizzaPrice - p1.PizzaCostToCompany)) as Profit,
concat(MONTHNAME(max(o1.OrderDetailsDateTime)),'-',DAY(max(o1.OrderDetailsDateTime)),'-',Year(max(o1.OrderDetailsDateTime))) as LastOrderDate
from pizza as p1
join orderdetails as o1
on p1.PizzaOrderID = o1.OrderDetailsID
group by p1.PizzaSizeType, p1.PizzaCrustType
order by profit desc;

SELECT *
FROM ProfitByPizza;

-- View No. 3

CREATE VIEW ProfitByOrderType AS
SELECT
	OrderDetailsType AS CustomerType, CONCAT(YEAR(o1.OrderDetailsDateTime), '-', MONTHNAME(o1.OrderDetailsDateTime)) AS OrderMonth, SUM((o1.OrderDetailsPrice)) AS TotalOrderPrice, 
    SUM((o1.OrderDetailsCostToCompany)) AS TotalOrderCost, (sum(o1.OrderDetailsPrice) - sum(o1.OrderDetailsCostToCompany)) AS Profit
    FROM
    orderdetails as o1
	GROUP BY CustomerType, OrderMonth
    UNION ALL
    SELECT
	'', 'Grand Total',  (SUM(OrderDetailsPrice)), (SUM(OrderDetailsCostToCompany)),
    (SUM(OrderDetailsPrice - OrderDetailsCostToCompany)) AS Profit
    FROM
    orderdetails;
    
SELECT * FROM ProfitByOrderType; 
