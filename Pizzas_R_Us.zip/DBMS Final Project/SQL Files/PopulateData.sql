use group16dbmsnew;

insert into topping
values(1, 'Pepperoni', 1.25, 0.2, 10, 100, 2,2.75,3.5, 4.5);
insert into topping
values(2, 'Sausage', 1.25, 0.15, 10, 100, 2.5,3,3.5, 4.25);
insert into topping
values(3, 'Ham', 1.5, 0.15, 10, 78, 2,2.5,3.25, 4);
insert into topping
values(4, 'Chicken', 1.75, 0.25, 10, 56, 1.5,2,2.25, 3);
insert into topping
values(5, 'Green Pepper', 0.5, 0.02, 10, 79, 1,1.5,2, 2.5);
insert into topping
values(6, 'Onion', 0.5, 0.02, 10, 85, 1,1.5,2, 2.75);
insert into topping
values(7, 'Roma Tomato', 0.75, 0.03, 10, 86, 2,3,3.5, 4.5);
insert into topping
values(8, 'Mushrooms', 0.75, 0.1, 10, 52, 1.5,2,2.5, 3);
insert into topping
values(9, 'Black Olives', 0.6, 0.1, 10, 39, 0.75,1,1.5, 2);
insert into topping
values(10, 'Pineapple', 1, 0.25, 10, 15, 1,1.25,1.75,2);
insert into topping
values(11, 'Jalapenos', 0.5, 0.05, 10, 64, 0.5,0.75,1.25, 1.75);
insert into topping
values(12, 'Banana Peppers', 0.5, 0.05, 10, 36, 0.6,1,1.3, 1.75);
insert into topping
values(13, 'Regular Cheese', 1.5, 0.12, 10, 250, 2,3.5,5, 7);
insert into topping
values(14, 'Four Cheese Blend', 2, 0.15, 10, 150, 2,3.5,5, 7);
insert into topping
values(15, 'Feta Cheese', 2, 0.18, 10, 75, 1.75,3,4, 5.5);
insert into topping
values(16, 'Goat Cheese', 2, 0.2, 10, 54, 1.6,2.75,4, 5.5);
insert into topping
values(17, 'Bacon', 1.5, 0.25, 10, 89, 1,1.5,2, 3);


insert into discount(DiscountName,DiscountPercentageOff,DiscountDollarsOff,DiscountIsPercentComplete) values
('Employee',15,0,true);
insert into discount(DiscountName,DiscountPercentageOff,DiscountDollarsOff,DiscountIsPercentComplete) values
('Lunch Special Medium',0,1.00,false);
insert into discount(DiscountName,DiscountPercentageOff,DiscountDollarsOff,DiscountIsPercentComplete) values
('Lunch Special Large',0,2.00,false);
insert into discount(DiscountName,DiscountPercentageOff,DiscountDollarsOff,DiscountIsPercentComplete) values
('Specialty Pizza',0,1.50,false);
insert into discount(DiscountName,DiscountPercentageOff,DiscountDollarsOff,DiscountIsPercentComplete) values
('Gameday Special',20,0,true);


insert into basecostprice values
('small','Thin', 3 , 0.5);
insert into basecostprice values
('small','Original',3 , 0.75);
insert into basecostprice values
('small','Pan',3.5 , 1);
insert into basecostprice values
('small','Gluten-Free', 4, 2);
insert into basecostprice values
('medium','Thin', 5, 1);
insert into basecostprice values
('medium','Original',5 ,1.5 );
insert into basecostprice values
('medium','Pan',6 , 2.25);
insert into basecostprice values
('medium','Gluten-Free',6.25 ,3 );
insert into basecostprice values
('large','Thin', 8, 1.25);
insert into basecostprice values
('large','Original', 8, 2);
insert into basecostprice values
('large','Pan',9 , 3);
insert into basecostprice values
('large','Gluten-Free',9.5 ,4 );
insert into basecostprice values
('x-large','Thin',10, 2);
insert into basecostprice values
('x-large','Original', 10, 3);
insert into basecostprice values
('x-large','Pan', 11.5, 4.5 );
insert into basecostprice values
('x-large','Gluten-Free', 12.5, 6);

-- Order1

insert into customer(CustomerFName, CustomerLName, CustomerPhone) values ('Shubham', 'Pardeshi', '888-121-2004');

insert into orderdetails(OrderDetailsCostToCompany,OrderDetailsPrice,OrderDetailsDateTime,OrderDetailsType,OrderDetailsCustomerID,OrderDetailsCompleted)
values(3.68,13.50,'2022-03-05 12:03:00','Dine-In',1,true);

insert into orderdiscountprice values(3,1);

insert into dinein values(1,14);

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Thin','large',3.68,13.50,'Completed',1,'2022-03-05 12:03:00');

insert into toppingbridge values(1,13,true);
insert into toppingbridge values(1,1,false);
insert into toppingbridge values(1,2,false);

-- order2
insert into customer(CustomerFName, CustomerLName, CustomerPhone) values ('Manan', 'Parikh', '777-123-0001');

insert into orderdetails(OrderDetailsCostToCompany,OrderDetailsPrice,OrderDetailsDateTime,OrderDetailsType,OrderDetailsCustomerID,OrderDetailsCompleted)
values(4.63,17.35,'2022-04-03 12:05:00','Dine-In',2,true);

insert into dinein values(2,4);

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Pan','medium',3.23,10.60,'Completed',2,'2022-04-03 12:05:00');

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','small',1.40,6.75,'Completed',2,'2022-04-03 12:05:00');

insert into pizzadiscountbridge values(2,2);
insert into pizzadiscountbridge values(4,2);

insert into toppingbridge values(2,15,false);
insert into toppingbridge values(2,9,false);
insert into toppingbridge values(2,7,false);
insert into toppingbridge values(2,8,false);
insert into toppingbridge values(2,12,false);

insert into toppingbridge values(3,13,false);
insert into toppingbridge values(3,4,false);
insert into toppingbridge values(3,12,false);

-- ORDER3
insert into customer(CustomerFName, CustomerLName, CustomerPhone) values ('Andrew', 'Wilkes-Krier', '864-254-5861');

insert into orderdetails(OrderDetailsCostToCompany,OrderDetailsPrice,OrderDetailsDateTime,OrderDetailsType,OrderDetailsCustomerID,OrderDetailsCompleted)
values(19.80,64.50,'2022-03-03 21:30:00','Pickup',3,true);

insert into pickup(PickUpOrderID) values(3); 

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','large',3.30,10.75,'Completed',3,'2022-03-03 21:30:00');
insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','large',3.30,10.75,'Completed',3,'2022-03-03 21:30:00');
insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','large',3.30,10.75,'Completed',3,'2022-03-03 21:30:00');
insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','large',3.30,10.75,'Completed',3,'2022-03-03 21:30:00');
insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','large',3.30,10.75,'Completed',3,'2022-03-03 21:30:00');
insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','large',3.30,10.75,'Completed',3,'2022-03-03 21:30:00');

insert into toppingbridge values(4,1,false);
insert into toppingbridge values(4,13,false);
insert into toppingbridge values(5,1,false);
insert into toppingbridge values(5,13,false);
insert into toppingbridge values(6,1,false);
insert into toppingbridge values(6,13,false);
insert into toppingbridge values(7,1,false);
insert into toppingbridge values(7,13,false);
insert into toppingbridge values(8,1,false);
insert into toppingbridge values(8,13,false);
insert into toppingbridge values(9,1,false);
insert into toppingbridge values(9,13,false);

-- order4
insert into orderdetails(OrderDetailsCostToCompany,OrderDetailsPrice,OrderDetailsDateTime,OrderDetailsType,OrderDetailsCustomerID,OrderDetailsCompleted)
values(16.86,45.50,'2022-04-20 19:11:00','Delivery',3,true);

insert into delivery values(
4,'864-254-5861','none','115 Party Blvd, Anderson','SC','29621'
);

insert into orderdiscountprice values(5,4);

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','x-large',5.59,14.50,'Completed',4,'2022-04-20 19:11:00');
insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','x-large',5.59,17.00,'Completed',4,'2022-04-20 19:11:00');
insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Original','x-large',5.68,14.00,'Completed',4,'2022-04-20 19:11:00');

insert into pizzadiscountbridge values(4,11);

insert into toppingbridge value(10,1,false);
insert into toppingbridge value(10,2,false);
insert into toppingbridge value(10,14,false);
insert into toppingbridge value(11,3,true);
insert into toppingbridge value(11,10,true);
insert into toppingbridge value(11,14,false);
insert into toppingbridge value(12,11,false);
insert into toppingbridge value(12,17,false);
insert into toppingbridge value(12,14,false);

-- order 5
insert into customer(CustomerFName, CustomerLName, CustomerPhone) values ('Matt', 'Engers', '864-474-9953');

insert into orderdetails(OrderDetailsCostToCompany,OrderDetailsPrice,OrderDetailsDateTime,OrderDetailsType,OrderDetailsCustomerID,OrderDetailsCompleted)
values(7.85,16.85,'2022-03-02 15:30:00','Pickup',4,true);

insert into pickup values(5);

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Gluten-Free','x-large',7.85,16.85,'Completed',5,'2022-03-02 15:30:00');

insert into pizzadiscountbridge values(4,13);

insert into toppingbridge values(13,5,false);
insert into toppingbridge values(13,6,false);
insert into toppingbridge values(13,7,false);
insert into toppingbridge values(13,8,false);
insert into toppingbridge values(13,9,false);
insert into toppingbridge values(13,16,false);

-- order 6
insert into customer(CustomerFName, CustomerLName, CustomerPhone) values ('Frank', 'Turner', '864-232-8944');

insert into orderdetails(OrderDetailsCostToCompany,OrderDetailsPrice,OrderDetailsDateTime,OrderDetailsType,OrderDetailsCustomerID,OrderDetailsCompleted)
values(3.20,13.25,'2022-03-02 18:17:00','Delivery',5,true);

insert into delivery values(
6,'864-232-8944','none','6745 Wessex St Anderson','SC','29621'
);

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Thin','large',3.20,13.25,'Completed',6,'2022-03-02 18:17:00');

insert into toppingbridge values(14,4,false);
insert into toppingbridge values(14,5,false);
insert into toppingbridge values(14,6,false);
insert into toppingbridge values(14,8,false);
insert into toppingbridge values(14,14,true);

-- order7
insert into customer(CustomerFName, CustomerLName, CustomerPhone) values ('Milo', 'Auckerman', '864-878-5679');

insert into orderdetails(OrderDetailsCostToCompany,OrderDetailsPrice,OrderDetailsDateTime,OrderDetailsType,OrderDetailsCustomerID,OrderDetailsCompleted)
values(6.30,24.00,'2022-04-13 20:32:00','Delivery',6,true);

insert into orderdiscountprice values(1,7);

insert into delivery values(
7,'864-878-5679','none','8879 Suburban Home, Anderson','SC','29621'
);

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Thin','large',3.75,12.00,'Completed',7,'2022-04-13 20:32:00');

insert into pizza(PizzaCrustType,PizzaSizeType,PizzaCostToCompany,PizzaPrice,PizzaState,PizzaOrderID,PizzaDateTime)
values('Thin','large',2.55,12.00,'Completed',7,'2022-04-13 20:32:00');

insert into toppingbridge values(15,14,true);
insert into toppingbridge values(16,13,false);
insert into toppingbridge values(16,1,true);

