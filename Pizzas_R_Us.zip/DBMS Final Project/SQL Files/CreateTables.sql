create schema group16dbmsnew;

use group16dbmsnew;

create table topping (
ToppingID int not null,
ToppingName varchar(60) not null,
ToppingPrice decimal(7,2) default 0,
ToppingCostToCompany decimal(7,2) not null,
ToppingMinInvLvl int not null,
ToppingCurrInvLvl int not null,
ToppingQuantitySmall decimal(7,2) default 0,
ToppingQuantityMedium decimal(7,2) default 0,
ToppingQuantityLarge decimal(7,2) default 0,
ToppingQuantityXlarge decimal(7,2) default 0,
PRIMARY KEY (ToppingID)
);

create table basecostprice (
BaseCostPriceSizeType varchar(30) not null,
BaseCostPriceCrustType varchar(30) not null,
BaseCostPriceCostToCompany decimal(7,2) not null,
BaseCostPriceTotalBasePrice decimal(7,2) not null,
PRIMARY KEY (BaseCostPriceSizeType,BaseCostPriceCrustType)
);

create table discount (
DiscountID int not null auto_increment,
DiscountName varchar(40) not null,
DiscountPercentageOff decimal(7,2) default 0,
DiscountDollarsOff decimal(7,2) default 0,
DiscountIsPercentComplete bool default false,
PRIMARY KEY (DiscountID)
);

create table customer (
CustomerID int not null auto_increment,
CustomerFName VARCHAR(40) not null,
CustomerLName VARCHAR(40) not null,
CustomerPhone VARCHAR(20) not null,
PRIMARY KEY (CustomerID)
);

create table orderdetails (
OrderDetailsID int not null auto_increment,
OrderDetailsPrice decimal(7,2) not null,
OrderDetailsCostToCompany decimal(7,2) not null,
OrderDetailsDateTime datetime not null,
OrderDetailsType varchar(20) not null,
OrderDetailsCustomerID int default 0,
OrderDetailsCompleted bool default false,
PRIMARY KEY (OrderDetailsID),
FOREIGN KEY (OrderDetailsCustomerID) REFERENCES customer (CustomerID)
);

create table pizza (
PizzaID int not null auto_increment,
PizzaCrustType varchar(20) not null,
PizzaSizeType varchar(20) not null, 
PizzaCostToCompany decimal(7,2) not null,
PizzaPrice decimal(7,2) not null,
PizzaState varchar(20) not null,
PizzaOrderID int not null, 
PizzaDateTime datetime not null,
PRIMARY KEY (PizzaID),
FOREIGN KEY (PizzaOrderID) REFERENCES orderdetails (OrderDetailsID),
FOREIGN KEY (PizzaSizeType, PizzaCrustType) REFERENCES basecostprice (BaseCostPriceSizeType, BaseCostPriceCrustType)
);

create table toppingbridge (
ToppingBridgePizzaID int not null,
ToppingBridgeToppingID int not null,
ToppingExtraYesOrNo bool default false,
PRIMARY KEY (ToppingBridgePizzaID, ToppingBridgeToppingID),
FOREIGN KEY (ToppingBridgePizzaID) REFERENCES pizza (PizzaID),
FOREIGN KEY (ToppingBridgeToppingID) REFERENCES topping (ToppingID)
);

create table pizzadiscountbridge (
PizzaDiscountBridgeDiscountID int not null,
PizzaDiscountBridgePizzaID int not null,
PRIMARY KEY (PizzaDiscountBridgeDiscountID, PizzaDiscountBridgePizzaID),
FOREIGN KEY (PizzaDiscountBridgePizzaID) REFERENCES pizza(PizzaID),
FOREIGN KEY (PizzaDiscountBridgeDiscountID) REFERENCES discount(DiscountID)
);

create table orderdiscountprice (
OrderDiscountPriceDiscountID int not null,
OrderDiscountPriceOrderID int not null,
PRIMARY KEY(OrderDiscountPriceDiscountID, OrderDiscountPriceOrderID),
FOREIGN KEY (OrderDiscountPriceDiscountID) REFERENCES discount (DiscountID),
FOREIGN KEY (OrderDiscountPriceOrderID ) REFERENCES orderdetails (OrderDetailsID)
);

create table dinein (
DineInOrderID int not null,
DineInTableNumber int not null,
PRIMARY KEY (DineInOrderID),
FOREIGN KEY (DineInOrderID) REFERENCES orderdetails (OrderDetailsID)
);

create table pickup (
PickUpOrderID int not null,
PRIMARY KEY (PickUpOrderID),
FOREIGN KEY (PickUpOrderID) REFERENCES orderdetails (OrderDetailsID)
);

create table delivery (
DeliveryOrderID int not null,
DeliveryCustomerPhone varchar(20) not null,
DeliveryCustomerEmail varchar(50),
DeliveryCustomerAddress VARCHAR(100) not null,
DeliveryState varchar(20) not null,
DeliveryZipcode varchar(10) not null,
PRIMARY KEY (DeliveryOrderID),
FOREIGN KEY (DeliveryOrderID) REFERENCES orderdetails (OrderDetailsID)
);