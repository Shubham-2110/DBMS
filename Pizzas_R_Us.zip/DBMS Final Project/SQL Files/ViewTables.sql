use group16dbmsnew;

select * from basecostprice;

select * from customer;

select * from delivery;

select * from dinein;

select * from discount;

select * from orderdiscountprice;

select * from orderdetails;

select * from pizzadiscountbridge;

select * from pickup;

select * from pizza;

select * from topping;

select * from toppingbridge;