use group16dbmsnew;

drop table topping;

drop table basecostprice;

drop table discount;

drop table customer;

drop table orderdetails;

drop table pizza;

drop table toppingbridge;

drop table pizzadiscountbridge;

drop table orderdiscountprice;

drop table dinein;

drop table pickup;

drop table delivery;