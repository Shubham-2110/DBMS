package cpsc4620;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.stream.Collectors;



public class Menu {
	
	private static Connection connection = null;
	public static void main(String[] args) throws SQLException, IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Welcome to Shubham & Manan's Pizzeria!");
		
		int menu_option = 0;

		PrintMenu();
		String option = reader.readLine();
		menu_option = Integer.parseInt(option);

		while (menu_option != 9) {
			switch (menu_option) {
			case 1:
				EnterOrder();
				break;
			case 2:
				viewCustomers();
				break;
			case 3:
				EnterCustomer();
				break;
			case 4:
				ViewOrders();
				break;
			case 5:
				MarkOrderAsComplete();
				break;
			case 6:
				ViewInventoryLevels();
				break;
			case 7:
				AddInventory();
				break;
			case 8:
				PrintReports();
				break;
			}
			PrintMenu();
			option = reader.readLine();
			menu_option = Integer.parseInt(option);
		}

	}

	public static void PrintMenu() {
		System.out.println("\n\nPlease enter a menu option:");
		System.out.println("1. Enter a new order");
		System.out.println("2. View Customers ");
		System.out.println("3. Enter a new Customer ");
		System.out.println("4. View orders");
		System.out.println("5. Mark an order as completed");
		System.out.println("6. View Inventory Levels");
		System.out.println("7. Add Inventory");
		System.out.println("8. View Reports");
		System.out.println("9. Exit\n\n");
		System.out.println("Enter your option: ");
	}

	
	public static void EnterOrder() throws SQLException, IOException 
	{
		
		Integer customerId;
		
		Boolean addMorePizza=true;
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		Order order = new Order();
		
		double orderTotalCost = 0;
		double orderTotalPrice = 0;
		
		System.out.println("Is this order for an existing customer : Answer y/n");
		
		String option = reader.readLine();
		
		String timeStamp = getTimeStamp();
		
		order.setOrderTimeStamp(timeStamp);

		
		if ("y".equals(option)) {
			System.out.println("Here is the list of customers select the customer : ");
			
			viewCustomers();
			
			System.out.println("Please enter a customer Id  : ");
			
			customerId = Integer.parseInt(reader.readLine());
			
		} else {
			customerId = EnterCustomer();
		}
		order.setCustID(customerId);
		
		
		
		System.out.println("Is this order for : \n1.Dine-In\n2.Pick-Up\n3.Delivery\nselect an option");
		
		Integer orderTypeInt = Integer.parseInt(reader.readLine());
		
		String orderType = Order.getOrderTypeFromId(orderTypeInt);
		
		order.setOrderType(orderType);
		
		
		
		DBNinja.addOrder(order);
		
		Integer orderId = order.getOrderID();
		
		
		
		if (Constants.OrderType.DINE_IN.equals(orderType)) {
			System.out.println("Enter the table number  ");
			Integer tableNumber = Integer.parseInt(reader.readLine());
			DBNinja.updateDineIn(orderId, tableNumber);
		} else if (Constants.OrderType.PICK_UP.equals(orderType)) {
			DBNinja.updatePickUp(orderId);
		} else {
			System.out.println("Enter the customer's phone in the XXX-XXX-XXXX numerical format:");
			String customerPhone = reader.readLine();
			System.out.println("Enter the customer's address(please do not enter address state and zip code):");
			String customerAddress = reader.readLine();
			System.out.println("Enter the customer's address state(SC,NY,KS,etc): ");
			String customerState = reader.readLine();
			System.out.println("Enter the customer's address zip code in the XXXXX numerical format: ");
			String customerZipCode = reader.readLine();
			System.out.println("Enter the customer's E-mail(e.g: abcd@ymail.com): ");
			String customerEmail = reader.readLine();
			DBNinja.updateDelivery(orderId, customerPhone, customerEmail, customerAddress, customerState, customerZipCode);
		}
		
		System.out.println("Let's add pizzas"); 
		
		while(addMorePizza)
		{
			System.out.println("Enter the details of the pizza\nWhat is the size of the pizza : \n1.Small\n2.Medium\n3.Large\n4.Extra_Large \nPlease enter an id:");
			
			Integer pizzaSize = Integer.parseInt(reader.readLine());
			
			System.out.println("What is the crust of the pizza : \n1.Thin\n2.Original\n3.Pan\n4.Gluten-Free \nPlease enter an id:");
			
			Integer pizzaCrust = Integer.parseInt(reader.readLine());
			
			String pizzaTimeStamp = getTimeStamp();
			
			Pizza pizza = new Pizza(orderId, Pizza.getPizzaCrustFromInt(pizzaCrust),
			        Pizza.getPizzaSizeFromInt(pizzaSize), pizzaTimeStamp);
			
			DBNinja.addPizza(pizza);
			

			Boolean wantMoreTopping = false;
			
			do {
				
				ViewInventoryLevels();
				
				System.out.println("Please enter a topping id from the above list if toppings is not required enter -1:");
				
				Integer toppingId = Integer.parseInt(reader.readLine());
				
				if (-1 == toppingId) {
					wantMoreTopping = false;
					break;
				} else {
					Topping topping = new Topping(toppingId, pizzaSize, pizza.getPizzaID());
					
					updatingInventoryForPizza(topping);
					
					pizza.addToppings(topping);
					
					
					
					
				}
				
				System.out.println("Do you want to add another topping : type y/n:");
				wantMoreTopping = "y".equals(reader.readLine());
				
			} while (wantMoreTopping);
			
			
			System.out.println("Do you want to add pizza Discount : type y/n:");
			
			Boolean addMoreDiscount = "y".equals(reader.readLine());
			
			
			while (addMoreDiscount) {
				
				ArrayList<Discount> discounts = DBNinja.getDiscountList();
				
				for (Discount discount : discounts) {
					System.out.println(discount.toString());
				}
				
				System.out.println("Please enter a discount id or -1 if you don't want to add a discount/n:");
				
				Integer discountId = Integer.parseInt(reader.readLine());
				
				if (-1 == discountId) {
					break;
				} else {
					
					Discount pizzaDiscount = new Discount(discountId);
					DBNinja.updateDiscountDetails(pizzaDiscount);
					DBNinja.insertInPizzaDiscount(pizza.getPizzaID(), discountId);
					
					pizza.addDiscounts(pizzaDiscount);
					
				}
				
				
				System.out.println("Do you want to add another discount : type y/n:");
				addMoreDiscount = "y".equals(reader.readLine());
				
			}
			
			DBNinja.updatePizzaDetails(pizza);
			
			orderTotalCost += pizza.getPizzaCost();
			orderTotalPrice += pizza.getPizzaPrice();

			System.out.println("Do you want to add another pizza : type y/n:");
			
			addMorePizza = "y".equals(reader.readLine());
			}
		
			order.setCustPrice(orderTotalPrice);
			order.setBusPrice(orderTotalCost);
		
		System.out.println("Do you want to add order Discount : type y/n:");
		
		Boolean addMoreDiscount = "y".equals(reader.readLine());
		
		//adding discount
		while (addMoreDiscount) {
			
			ArrayList<Discount> discounts = DBNinja.getDiscountList();
			
			for (Discount discount : discounts) {
				System.out.println(discount.toString());
			}
			
			System.out.println("Please enter a discount id or -1 if you don't want to add a discount/n:");
			
			Integer discountId = Integer.parseInt(reader.readLine());
			
			if (-1 == discountId) {
				break;
			} else {
				
				Discount pizzaDiscount = new Discount(discountId);
				DBNinja.updateDiscountDetails(pizzaDiscount);
				DBNinja.insertInOrderDiscount(order.getOrderID(), discountId);
				
				order.addDiscounts(pizzaDiscount);
				
			}
			
			System.out.println("Do you want to add another discount : type y/n:");
			addMoreDiscount = "y".equals(reader.readLine());
			
		}
		
		DBNinja.updateOrderDetails(order);
		
		

		System.out.println("Finished adding order...Returning to menu...");
	}
	
	private static String getTimeStamp() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
		LocalDateTime now = LocalDateTime.now();
		return dtf.format(now);
	}
	
	private static void updatingInventoryForPizza(Topping topping) {
		
		Hashtable<String, Boolean> toppingBooleans = DBNinja.getOrderTopping(topping);
		
		if (toppingBooleans.get("isToppingExist")) {
			if (toppingBooleans.get("isThisExtraTopping")) {
				System.out.println("Already added the topic twice");
			} else {
				DBNinja.getToppingDetails(topping);
				DBNinja.updateIsExtraBoolean(topping);
				topping.setBusPrice(topping.getBusPrice() * 2);
				topping.setCustPrice(topping.getCustPrice() * 2);
			}
		} else {
			DBNinja.getToppingDetails(topping);
			
			DBNinja.addOrderTopping(topping);
		}
		
	}
	
	public static void printProducts() {
		try {
		      connection = DBConnector.make_connection();
		    } catch (Exception e) {
		      System.out.println(e);
		    }
		try (Statement statement = connection.createStatement();
		        ResultSet rs = statement.executeQuery("select * from basecostprice;")) {
			
			System.out.println("Product list:");
			while (rs.next()) {
				String size = rs.getString("BaseCostPriceSizeType");
				String price = rs.getString("BaseCostPriceTotalBasePrice");
				double cost = rs.getDouble("BaseCostPriceCostToCompany");
				
				System.out.println("success " + size + cost + "price " + price);
				
			}
			System.out.println();
		}
		catch (SQLException e) {
			System.out.println(e);
		}
	}
	
	
	public static void viewCustomers()
	{
		
		ArrayList<Customer> customers;
		try {
			customers = DBNinja.getCustomerList();
		
			for (Customer customer : customers) {
				System.out.println(customer.toString());
			}
		}
		catch (SQLException | IOException e) {
			System.out.println("There was error in displaying the customers " + e);
			e.printStackTrace();
		}
		
		
		
		
	}
	

	
	public static Integer EnterCustomer() throws SQLException, IOException
	{
		
		Integer updatedCustomerId;
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		System.out.println("Enter customer's First Name <Space> Last Name ");

		String name = reader.readLine();
		
		int idx = name.lastIndexOf(' ');
		if (idx == -1)
			throw new IllegalArgumentException("Only a single name: " + name);
		String firstName = name.substring(0, idx);
		String lastName = name.substring(idx + 1);
		
		System.out.println("Enter the customer's phone number in the format: XXX-XXX-XXXX");
		
		String phoneNumber = reader.readLine();
		
		Customer customer = new Customer(0, firstName, lastName, phoneNumber);
		try {
			updatedCustomerId = DBNinja.addCustomer(customer);
		}
		catch (Exception e) {
			System.out.println("There has been an error while adding the customer " + e);
			throw e;
		}
		return updatedCustomerId;
	}

	
	public static void ViewOrders() throws SQLException, IOException 
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
	ArrayList<Order> orders = null;
	
	
	System.out.println("Would you like to :\na. Display all orders\nb. Orders since a specific date ");
	
	String option = reader.readLine();
	try {
		if ("a".equals(option)) {
			orders = DBNinja.getCurrentOrders();
		} else {
			System.out.println("Enter the date in YYYY-MM-DD format");
			String date = reader.readLine();
			orders = DBNinja.getCurrentOrders(date);
		}
		
		for (Order order : orders) {
			System.out.println(order.toSimplePrint());
		}
		System.out.println("Enter the id of the order which you want to see in detail: ");
		Integer particularOrder = Integer.parseInt(reader.readLine());
		Map<Integer, Order> resultMap = orders.stream().collect(Collectors.toMap(x -> x.getOrderID(), x -> x));
		resultMap.get(particularOrder);
		
		System.out.println(resultMap.get(particularOrder).toString());
	}
	catch (SQLException | IOException e) {
		
		e.printStackTrace();
	}
	
	}

	
	
	public static void MarkOrderAsComplete() throws SQLException, IOException 
	{
		ArrayList<Order> orders = DBNinja.getCurrentOrders(0);
		for (Order order : orders) {
			System.out.println(order.toSimplePrint());
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		
		System.out.println("Enter the order ID that you wish to mark as completed :");
		Integer orderId = Integer.parseInt(reader.readLine());
		DBNinja.markOrderAsComplete(orderId);
		
	}

	
	public static ArrayList<Topping> ViewInventoryLevels() throws SQLException, IOException
	{
		
		ArrayList<Topping> toppings = DBNinja.getInventory();		
		if (!toppings.isEmpty()) {
			System.out.printf(" Toppings List         %n");
			
			System.out.printf(" %-4s | %-17s | %20s %n", "Id", "Topping", "Current Inventory Level");
			System.out.printf("-----------------------------------------------------%n");
			for (Topping topping : toppings)
				System.out.printf(" %-4s | %-17s | %4s %n", topping.getTopID(), topping.getTopName(),
				    topping.getCurINVT());
			
		}
		return toppings;
		
	}

	
	public static void AddInventory() throws SQLException, IOException 
	{
		
		ViewInventoryLevels();
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

		
		System.out.println("Enter the id of the inventory that you want to add : ");
		
		Integer toppingId = Integer.parseInt(reader.readLine());
		System.out.println("Enter the units of the inventory that you want to add : ");
		
		Double amountToAdd = Double.parseDouble(reader.readLine());
		
		DBNinja.updateInventory(toppingId, amountToAdd);
		
		
	}


	
	public static void PrintReports() throws SQLException, NumberFormatException, IOException
	{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println(
		    "Which report do you wish to print? Enter\n1. ToppingPopularity\n2. ProfitByPizza\n3. ProfitByOrderType");
		Integer option = Integer.parseInt(reader.readLine());
		
		switch (option) {
			case 1:
				DBNinja.printToppingReport();
				
				break;
			case 2:
				DBNinja.printProfitByPizzaReport();
				break;
			case 3:
				DBNinja.printProfitByOrderReport();
				break;
		}
	}

}
