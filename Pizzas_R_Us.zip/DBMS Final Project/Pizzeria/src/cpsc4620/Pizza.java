package cpsc4620;
import java.util.ArrayList;
import java.util.Hashtable;

public class Pizza 
{
	
	
	
	private int PizzaID;
	private String CrustType;
	private String Size;
	private int OrderID;
	private String PizzaState;
	private String PizzaDate;
	
	private double pizzaPrice;
	
	private double pizzaCost;
	
	
	private ArrayList<Topping> Toppings;
	private ArrayList<Discount> Discounts;
	
	
	private boolean[] isToppingDoubled;
	
	
	public Pizza(int pizzaID, String size, String crustType, int orderID, String pizzaState, String pizzaDate,
	    double pizzaCost, double pizzaPrice) {
		PizzaID = pizzaID;
		CrustType = crustType;
		Size = size;
		OrderID = orderID;
		PizzaState = pizzaState;
		PizzaDate = pizzaDate;
		pizzaCost = this.pizzaCost;
		pizzaPrice = this.pizzaPrice;
		Toppings = new ArrayList<Topping>();
		isToppingDoubled = new boolean[17];
		Discounts = new ArrayList<Discount>();
	}

	public Pizza(int orderID, String pizzaCrust, String pizzaSize, String pizzaTimeStamp) {
		CrustType = pizzaCrust;
		Size = pizzaSize;
		OrderID = orderID;
		PizzaDate = pizzaTimeStamp;
		Toppings = new ArrayList<Topping>();
		Discounts = new ArrayList<Discount>();
		
	}
	
	public int getPizzaID() {
		return PizzaID;
	}



	public String getCrustType() {
		return CrustType;
	}



	public String getSize() {
		return Size;
	}



	public int getOrderID() {
		return OrderID;
	}



	public String getPizzaState() {
		return PizzaState;
	}



	public String getPizzaDate() {
		return PizzaDate;
	}





	public ArrayList<Topping> getToppings() {
		return Toppings;
	}



	public ArrayList<Discount> getDiscounts() {
		return Discounts;
	}



	public void setPizzaID(int pizzaID) {
		PizzaID = pizzaID;
	}



	public void setCrustType(String crustType) {
		CrustType = crustType;
	}



	public void setSize(String size) {
		Size = size;
	}



	public void setOrderID(int orderID) {
		OrderID = orderID;
	}



	public void setPizzaState(String pizzaState) {
		PizzaState = pizzaState;
	}



	public void setPizzaDate(String pizzaDate) {
		PizzaDate = pizzaDate;
	}


	public void setToppings(ArrayList<Topping> toppings) {
		Toppings = toppings;
	}



	public void setDiscounts(ArrayList<Discount> discounts) {
		Discounts = discounts;
	}

	public void addToppings(Topping t)
	{
		Toppings.add(t);
		
			
		pizzaCost += t.getBusPrice();
		pizzaPrice += t.getCustPrice();


	}
	
	public void addDiscounts(Discount d)
	{
		Discounts.add(d);
		if(d.isPercent())
		{
			pizzaPrice -= (pizzaPrice * (1 - (d.getDiscountDollarsOff() / 100)));
		}
		else
		{
			pizzaPrice -= d.getDiscountDollarsOff();
		}
	}

	
	
	public void modifyDoubledArray(int index, boolean b)
	{
		isToppingDoubled[index] = b;
	}
	
	
	public boolean[] getIsDoubleArray()
	{
		return isToppingDoubled;
	}
	
	@Override
	public String toString() {
		return "PizzaID=" + PizzaID + " | CrustType= " + CrustType + ", Size= " + Size + " | For order " + OrderID
		        + " | Pizza Status: " + PizzaState + ", as of " + PizzaDate + " | Customer Price= " + pizzaPrice
		        + " | Business Price= " + pizzaCost;
	}
	
	public static String getPizzaSizeFromInt(Integer pizzaSize) {
		Hashtable<Integer, String> pizzaSizeHash = new Hashtable<Integer, String>();
		pizzaSizeHash.put(1, Constants.PizzaSize.SMALL);
		pizzaSizeHash.put(2, Constants.PizzaSize.MEDIUM);
		pizzaSizeHash.put(3, Constants.PizzaSize.LARGE);
		pizzaSizeHash.put(4, Constants.PizzaSize.EXTRA_LARGE);
		
		return pizzaSizeHash.get(pizzaSize);
	}
	
	public static String getPizzaCrustFromInt(Integer pizzaCrust) {
		Hashtable<Integer, String> pizzaCrustHash = new Hashtable<Integer, String>();
		pizzaCrustHash.put(1, Constants.PizzaCrust.THIN);
		pizzaCrustHash.put(2, Constants.PizzaCrust.ORIGINAL);
		pizzaCrustHash.put(3, Constants.PizzaCrust.PAN);
		pizzaCrustHash.put(4, Constants.PizzaCrust.GLUTEN_FREE);
		
		return pizzaCrustHash.get(pizzaCrust);
	}
	
	public double getPizzaPrice() {
		return pizzaPrice;
	}
	
	public void setPizzaPrice(double pizzaPrice) {
		this.pizzaPrice = pizzaPrice;
	}
	
	public double getPizzaCost() {
		return pizzaCost;
	}
	
	public void setPizzaCost(double pizzaCost) {
		this.pizzaCost = pizzaCost;
	}
	
	
}
