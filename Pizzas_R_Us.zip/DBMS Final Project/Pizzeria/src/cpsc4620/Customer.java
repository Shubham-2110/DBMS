package cpsc4620;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

public class Customer 
{
	
	
	private int CustID;
	private String FName;
	private String LName;
	private String Phone;
	
	
	
	public Customer(int custID, String fName, String lName, String phone) {
		CustID = custID;
		FName = fName;
		LName = lName;
		Phone = phone;
	}

	public int getCustID() {
		return CustID;
	}

	public String getFName() {
		return FName;
	}

	public String getLName() {
		return LName;
	}

	public String getPhone() {
		return Phone;
	}

	public void setCustID(int custID) {
		CustID = custID;
	}

	public void setFName(String fName) {
		FName = fName;
	}

	public void setLName(String lName) {
		LName = lName;
	}

	public void setPhone(String phone) {
		Phone = phone;
	}
	

	
	@Override
	public String toString() {
		return "CustID=" + CustID + " | Name= " + FName +  " " + LName + ", Phone= " + Phone;
	}
	
	public void displayCustomer() throws SQLException, IOException {
		
		ArrayList<Customer> customers = DBNinja.getCustomerList();
		for (Customer customer : customers) {
			System.out.println(customer.toString());
		}
		
	}
	
}
