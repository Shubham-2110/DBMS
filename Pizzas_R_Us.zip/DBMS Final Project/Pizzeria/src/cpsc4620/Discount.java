package cpsc4620;

public class Discount 
{
	
	
	
	private int DiscountID;
	private String DiscountName;
	private double DiscountPercentageOff;
	private double DiscountDollarsOff;
	private boolean isPercent;
	
	
	public Discount(int discountID, String discountName, double discountPercentageOff, double discountDollarsOff,boolean isPercent){
		DiscountID = discountID;
		DiscountName = discountName;
		DiscountPercentageOff = discountPercentageOff;
		DiscountDollarsOff = discountDollarsOff;
		this.isPercent = isPercent;
	}

	public Discount(Integer discountId) {
		DiscountID = discountId;
	}
	
	public int getDiscountID() {
		return DiscountID;
	}

	public String getDiscountName() {
		return DiscountName;
	}



	public boolean isPercent() {
		return isPercent;
	}
	
	public double getDiscountPercentageOff() {
		return DiscountPercentageOff;
	}
	
	public double getDiscountDollarsOff() {
		return DiscountDollarsOff;
	}

	public void setDiscountID(int discountID) {
		DiscountID = discountID;
	}

	public void setDiscountName(String discountName) {
		DiscountName = discountName;
	}
	
	public void setDiscountPercentageOff(double discountPercentageOff) {
		DiscountPercentageOff = discountPercentageOff;
	}
	
	public void setDiscountDollarsOff(double discountDollarsOff) {
		DiscountDollarsOff = discountDollarsOff;
	}



	public void setPercent(boolean isPercent) {
		this.isPercent = isPercent;
	}


	
	@Override
	public String toString() {
		return "DiscountID=" + DiscountID + " | " + DiscountName + ", DiscountPercentageOff= " + DiscountPercentageOff 
				+ ", DiscountDollarsOff= " + DiscountDollarsOff + ", isPercent= " + isPercent;
	}
	
}
