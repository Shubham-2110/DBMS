package cpsc4620;

public class DineinOrder extends Order{
	
	
	
	private int TableNum;
	


	public int getTableNum() {
		return TableNum;
	}

	public void setTableNum(int tableNum) {
		TableNum = tableNum;
	}
	
	@Override
	public String toString() {
		return super.toString() + " | Customer was sat at table number " + TableNum;
	}
}
