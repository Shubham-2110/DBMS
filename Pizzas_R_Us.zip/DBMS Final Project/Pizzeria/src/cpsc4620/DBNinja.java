package cpsc4620;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Hashtable;



public final class DBNinja {
	
	private static Connection conn;
	
	private static boolean connect_to_db() throws SQLException, IOException {
		
		try {
			conn = DBConnector.make_connection();
			return true;
		}
		catch (SQLException e) {
			return false;
		}
		catch (IOException e) {
			return false;
		}
		
	}
	
	
	
	public static void addOrder(Order order) throws SQLException, IOException {
		connect_to_db();
		
		order.getOrderType();
		Integer customerId = order.getCustID();
		
		String[] generatedId = { "ID" };
		
		String insertStatement = "INSERT INTO orderdetails"
		        + "(OrderDetailsPrice,OrderDetailsType,OrderDetailsDateTime,OrderDetailsCompleted,OrderDetailsCostToCompany,OrderDetailsCustomerId) " + "VALUES (0.00,'"
		        + order.getOrderType() + "','" + order.getOrderTimeStamp() + "',false,0.00," + customerId + ")";
		
		PreparedStatement preparedStatement = conn.prepareStatement(insertStatement, generatedId);
		
		int result = preparedStatement.executeUpdate();
		
		if (result > 0) {
			try {
				ResultSet resultSet = preparedStatement.getGeneratedKeys();
				if (resultSet.next()) {
					order.setOrderID(resultSet.getInt(1));
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				try {
					conn.close();
				}
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	
	public static void addPizza(Pizza pizza) throws SQLException, IOException {
		try {
			
			connect_to_db();
			
			
			DBNinja.getBasePizzaDetails(pizza);
			
			String[] generatedId = { "ID" };
			
			String insertStatement = "insert into pizza(PizzaOrderId,PizzaSizeType,PizzaCrustType,PizzaState,PizzaDateTime,PizzaCostToCompany,PizzaPrice)\n"
			        + "values\n" + "(" + pizza.getOrderID() + ",'" + pizza.getSize() + "','" + pizza.getCrustType()
			        + "',FALSE,'" + pizza.getPizzaDate() + "'," + pizza.getPizzaCost() + "," + pizza.getPizzaPrice() + ")";
			
			PreparedStatement preparedStatement = conn.prepareStatement(insertStatement, generatedId);
			
			int result = preparedStatement.executeUpdate();
			
			if (result > 0) {
				ResultSet resultSet = preparedStatement.getGeneratedKeys();
				if (resultSet.next()) {
					pizza.setPizzaID(resultSet.getInt(1));
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	

	
	
	public static Integer addCustomer(Customer customer) throws SQLException, IOException {
		connect_to_db();
		
		String firstName = customer.getFName();
		String lastName = customer.getLName();
		String phoneNumber = customer.getPhone();
		Integer customerId = null;
		
		String[] generatedId = { "ID" };
		
		String insertStatement = "INSERT INTO customer(CustomerFName,CustomerLName,CustomerPhone) VALUES (?,?,?)";
		
		PreparedStatement preparedStatement = conn.prepareStatement(insertStatement, generatedId);
		
		preparedStatement.setString(1, firstName);
		preparedStatement.setString(2, lastName);
		preparedStatement.setString(3, phoneNumber);
		
		int result = preparedStatement.executeUpdate();
		
		if (result > 0) {
			try {
				ResultSet rs = preparedStatement.getGeneratedKeys();
				if (rs.next()) {
					customerId = rs.getInt(1);
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			finally {
				try {
					conn.close();
				}
				catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
		return customerId;
		
	}
	
	public static void updateInventory(Integer toppingId, Double value) throws SQLException, IOException {
		connect_to_db();
		
		String updateStatement = "update topping set ToppingCurrInvLvl = ToppingCurrInvLvl +(?) where ToppingId = ? ;";
		
		PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);
		
		preparedStatement.setDouble(1, value);
		
		preparedStatement.setInt(2, toppingId);
		
		preparedStatement.executeUpdate();
		
	}
	
	public static ArrayList<Topping> getInventory() throws SQLException, IOException {
		ArrayList<Topping> toppings = new ArrayList<Topping>();
		connect_to_db();
		
		try (Statement statement = conn.createStatement();
		        ResultSet resultSet = statement.executeQuery("select * from topping order by ToppingName ;")) {
			
			while (resultSet.next()) {
				Integer toppingId = resultSet.getInt("ToppingId");
				String toppingName = resultSet.getString("ToppingName");
				Integer currentInventoryLevel = resultSet.getInt("ToppingCurrInvLvl");
				
				toppings.add(new Topping(toppingId, toppingName, currentInventoryLevel));
				
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return toppings;
	}
	
	
	public static String getCustomerName(int CustID) throws SQLException, IOException {
		connect_to_db();
		String ret = "";
		String query = "Select CustomerFName, CustomerLName From customer WHERE CustomerID=" + CustID + ";";
		Statement stmt = conn.createStatement();
		ResultSet rset = stmt.executeQuery(query);
		
		while (rset.next()) {
			ret = rset.getString(1) + " " + rset.getString(2);
		}
		conn.close();
		return ret;
	}
	
	public static ArrayList<Discount> getDiscountList() throws SQLException, IOException {
		ArrayList<Discount> discounts = new ArrayList<Discount>();
		connect_to_db();
		try (Statement statement = conn.createStatement();
		        ResultSet resultSet = statement.executeQuery("select * from discount;")) {
			
			System.out.println("Getting Discount list:");
			while (resultSet.next()) {
				Integer discountId = resultSet.getInt("DiscountID");
				String discountName = resultSet.getString("DiscountName");
				Boolean isPercentDiscount = resultSet.getBoolean("DiscountIsPercentComplete");
				
				
				Double discountPercentageOff = resultSet.getDouble("DiscountPercentageOff");
				Double discountDollarsOff = resultSet.getDouble("DiscountDollarsOff");
				
				
				discounts.add(new Discount(discountId, discountName,discountPercentageOff, discountDollarsOff,isPercentDiscount));
				
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return discounts;
	}
	
	
	public static ArrayList<Customer> getCustomerList() throws SQLException, IOException {
		ArrayList<Customer> customers = new ArrayList<Customer>();
		connect_to_db();
		try (Statement statement = conn.createStatement();
		        ResultSet resultSet = statement.executeQuery("select * from customer;")) {
			
			
			while (resultSet.next()) {
				Integer customerId = resultSet.getInt("CustomerID");
				String customerFirstName = resultSet.getString("CustomerFName");
				String customerLastName = resultSet.getString("CustomerLName");
				String customerPhone = resultSet.getString("CustomerPhone");
				
				customers.add(new Customer(customerId, customerFirstName, customerLastName, customerPhone));
				
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return customers;
	}
	
	public static void getBasePizzaDetails(Pizza pizza) {
		
		
		try {
			String pizzaCrust = pizza.getCrustType();
			String pizzaSize = pizza.getSize();
			
			try (Statement statement = conn.createStatement();
			        ResultSet resultSet = statement.executeQuery("select * from basecostprice where PizzaCrustType = '" + pizzaCrust
			                + "' and PizzaSizeType = '" + pizzaSize + "';")) {
				
				while (resultSet.next()) {
					
					pizza.setPizzaPrice(resultSet.getDouble("PizzaPrice"));
					pizza.setPizzaCost(resultSet.getDouble("PizzaCostToCompany"));
					
				}
			}
		}
		catch (Exception e) {
			
		}
		

	}
	
	public static void getToppingDetails(Topping topping) {
		 
		
		Double toppingQuantity = 0d;
		try {
			connect_to_db();
			
			try (Statement statement = conn.createStatement();
			        ResultSet resultSet = statement
			                .executeQuery("select * from topping where ToppingId = " + topping.getTopID() + ";")) {
				
				while (resultSet.next()) {
					toppingQuantity = resultSet.getDouble(topping.getPizzaToppingSize());
					topping.setBusPrice(resultSet.getDouble("ToppingCostToCompany") * toppingQuantity);
					topping.setCustPrice(resultSet.getDouble("ToppingPrice") * toppingQuantity);
				}
			}
			updateInventory(topping.getTopID(), -1 * (toppingQuantity));
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static Hashtable<String, Boolean> getOrderTopping(Topping topping) {
		
		
		Hashtable<String, Boolean> resultBooleans = new Hashtable<>();
		Boolean isToppingExist = false;
		Boolean isThisExtraTopping = false;
		try {
			connect_to_db();
			try (Statement statement = conn.createStatement();
			        ResultSet resultSet = statement.executeQuery("select * from toppingbridge where ToppingBridgePizzaID = "
			                + topping.getPizzaId() + " and ToppingBridgeToppingID = " + topping.getTopID() + ";")) {
				
				while (resultSet.next()) {
					isToppingExist = true;
					isThisExtraTopping = resultSet.getBoolean("ToppingExtraYesOrNo");
				}
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		resultBooleans.put("isToppingExist", isToppingExist);
		resultBooleans.put("isThisExtraTopping", isThisExtraTopping);
		
		return resultBooleans;
	}
	
	public static void updateIsExtraBoolean(Topping topping) {
		
		
		try {
			connect_to_db();
			
			String updateStatement = "update toppingbridge set ToppingExtraYesOrNo = true where ToppingBridgePizzaID = ? and ToppingBridgeToppingID = ?;";
			
			PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);
			
			preparedStatement.setInt(1, topping.getPizzaId());
			
			preparedStatement.setInt(2, topping.getTopID());
			
			preparedStatement.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void addOrderTopping(Topping topping) {
	
		try {
			connect_to_db();
			String insertStatement = "insert into toppingbridge(ToppingBridgePizzaID,ToppingBridgeToppingID,ToppingExtraYesOrNo)" + "values" + "("
			        + topping.getPizzaId() + "," + topping.getTopID() + ",false);";
			
			PreparedStatement preparedStatement;
			
			preparedStatement = conn.prepareStatement(insertStatement);
			preparedStatement.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void updateDiscountDetails(Discount discount) {
		
		
		try {
			connect_to_db();
			try (Statement statement = conn.createStatement();
			        ResultSet resultSet = statement
			                .executeQuery("select * from discount where DiscountID = " + discount.getDiscountID() + ";")) {
				
				while (resultSet.next()) {
					
					discount.setDiscountName(resultSet.getString("DiscountName"));
					discount.setPercent(resultSet.getBoolean("DiscountIsPercentComplete"));
				}
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void updatePizzaDetails(Pizza pizza) {
		
		
		try {
			connect_to_db();
			String updateStatement = "update pizza set PizzaCostToCompany = ?, PizzaPrice = ? where PizzaOrderID = ? ;";
			
			PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);
			
			preparedStatement.setDouble(1, pizza.getPizzaCost());
			
			preparedStatement.setDouble(2, pizza.getPizzaPrice());
			
			preparedStatement.setInt(3, pizza.getPizzaID());
			
			preparedStatement.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void updateOrderDetails(Order ordertable) {
		
		try {
			connect_to_db();
			String updateStatement = "update orderdetails set OrderDetailsCostToCompany = ?, OrderDetailsPrice = ? where OrderDetailsId = ? ;";
			
			PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);
			
			preparedStatement.setDouble(1, ordertable.getBusPrice());
			
			preparedStatement.setDouble(2, ordertable.getCustPrice());
			
			preparedStatement.setInt(3, ordertable.getOrderID());
			
			preparedStatement.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static ArrayList<Order> getCurrentOrders() throws SQLException, IOException {
		return getCurrentOrders(null, null);
	}
	
	public static ArrayList<Order> getCurrentOrders(String date) {
		return getCurrentOrders(date, null);
		
	}
	
	public static ArrayList<Order> getCurrentOrders(Integer status) {
		return getCurrentOrders(null, status);
		
	}
	
	public static ArrayList<Order> getCurrentOrders(String date, Integer status) {
		
		ArrayList<Order> orders = new ArrayList<Order>();
		
		try {
			connect_to_db();
			
			String selectQuery = "select * from orderdetails";
			if (date != null) {
				selectQuery += " where (OrderDetailsDateTime >= '" + date + " 00:00:00')";
			} else if (status != null) {
				selectQuery += " where OrderDetailsCompleted = " + status;
			}
			selectQuery += " order by OrderDetailsId desc;";
			
			Statement statement = conn.createStatement();
			
			ResultSet resultSet = statement.executeQuery(selectQuery);
			
			while (resultSet.next()) {
				Integer orderId = resultSet.getInt("OrderDetailsId");
				String orderType = resultSet.getString("OrderDetailsType");
				Integer customerId = resultSet.getInt("OrderDetailsCustomerId");
				Double orderCost = resultSet.getDouble("OrderDetailsCostToCompany");
				Double orderPrice = resultSet.getDouble("OrderDetailsPrice");
				String orderTimeStamp = resultSet.getString("OrderDetailsDateTime");
				Integer OrderCompleteState = resultSet.getInt("OrderDetailsCompleted");
				
				orders.add(
				    new Order(orderId, customerId, orderType, orderTimeStamp, orderCost, orderPrice, OrderCompleteState));
				
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return orders;
	}
	
	public static void markOrderAsComplete(Integer orderId) {
	
		try {
			connect_to_db();
			
			String updateStatement = "update orderdetails set OrderDetailsCompleted = 1 where OrderDetailsID = " + orderId + " ;";
			
			PreparedStatement preparedStatement = conn.prepareStatement(updateStatement);
			
			preparedStatement.executeUpdate();
			
			String updatePizzaStatement = "update pizza set PizzaState = 1 where PizzaOrderID = " + orderId + " ;";
			
			PreparedStatement pizzaPreparedStatement = conn.prepareStatement(updatePizzaStatement);
			
			pizzaPreparedStatement.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void insertInPizzaDiscount(int pizzaID, Integer discountId) {
		
		String insertStatement = "insert into pizzadiscountbridge(PizzaDiscountBridgePizzaID,PizzaDiscountBridgeDiscountID)" + "values" + "(" + pizzaID + ","
		        + discountId + ")";
		
		PreparedStatement preparedStatement;
		try {
			connect_to_db();
			preparedStatement = conn.prepareStatement(insertStatement);
			preparedStatement.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void insertInOrderDiscount(int orderId, Integer discountId) {
		
		
		String insertStatement = "insert into orderdiscountprice(OrderDiscountPriceOrderID,OrderDiscountPriceDiscountID)" + "values" + "(" + orderId + ","
		        + discountId + ")";
		
		PreparedStatement preparedStatement;
		try {
			connect_to_db();
			preparedStatement = conn.prepareStatement(insertStatement);
			preparedStatement.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void printToppingReport() {
		
		try {
			connect_to_db();
			
			Statement statement = conn.createStatement();
			String query = "select  topping.ToppingName as Topping , count(topping.ToppingName) + "
					+ "sum(toppingbridge.ToppingExtraYesOrNo) as  ToppingCount from toppingbridge right join topping  "
					+ "on toppingbridge.ToppingBridgePizzaID=topping.ToppingID group by topping.ToppingName order by ToppingCount desc;";
			ResultSet resultSet = statement.executeQuery(query);
			System.out.printf("%-20s | %-4s |%n", "Topping", "ToppingCount");
			System.out.printf("-------------------------------------\n");
			while (resultSet.next()) {
				
				Integer count = resultSet.getInt("ToppingCount");
				String topping = resultSet.getString("Topping");
				System.out.printf("%-20s | %-4s |%n", topping, count);
				
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void printProfitByPizzaReport() {
		try {
			connect_to_db();
			
			Statement statement = conn.createStatement();
			
			String query = "select  basecostprice.BaseCostPriceSizeType as 'Pizza Size', basecostprice.BaseCostPriceCrustType as 'Pizza Crust',  "
					+ "sum(pizza.PizzaPrice-pizza.PizzaCostToCompany) as Profit ,  "
					+ "DATE_FORMAT(max(pizza.PizzaDateTime), '%M %e %Y') as LastOrderDate from basecostprice right join pizza  "
					+ "on basecostprice.BaseCostPriceSizeType=pizza.PizzaSizeType and basecostprice.BaseCostPriceCrustType=pizza.PizzaCrustType "
					+ "group by basecostprice.BaseCostPriceSizeType,basecostprice.BaseCostPriceCrustType order by Profit desc;";
			
			ResultSet resultSet = statement.executeQuery(query);
			System.out.printf("%-15s | %-15s | %-10s| %-30s%n", "Pizza Size", "Pizza Crust", "Profit", "Last Order Date");
			System.out.printf("-----------------------------------------------------------------\n");
			while (resultSet.next()) {
				
				String size = resultSet.getString("Pizza Size");
				String crust = resultSet.getString("Pizza Crust");
				String lastOrderDate = resultSet.getString("LastOrderDate");
				Double profit = resultSet.getDouble("Profit");
				System.out.printf("%-15s | %-15s | %-10s| %-30s%n", size, crust, profit, lastOrderDate);
				
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void printProfitByOrderReport() {
		try {
			connect_to_db();
			
			Statement statement = conn.createStatement();
			
			String query = " select  OrderDetailsType as CustomerType, DATE_FORMAT(OrderDetailsDateTime,'%Y %M') as OrderMonth, "
					+ "OrderDetailsPrice as TotalOrderPrice ,OrderDetailsCostToCompany as TotalOrderCost , (OrderDetailsPrice-OrderDetailsCostToCompany) as Profit "
					+ "from orderdetails group by CustomerType,OrderMonth\n"
			        + "union\n"
			        + "select ' ','Grand Total' as OrderMonth, sum(OrderDetailsPrice) as TotalOrderPrice ,sum(OrderDetailsCostToCompany) as TotalOrderCost, "
			        + "sum(OrderDetailsPrice-OrderDetailsCostToCompany) as profit from orderdetails;";
			
			ResultSet resultSet = statement.executeQuery(query);
			System.out.printf("%-15s | %-15s | %-18s| %-18s| %-8s%n", "Customer Type", "Order Month", "Total Order Price",
			    "Total Order Cost", "Profit");
			System.out.printf("-----------------------------------------------------------------------------------\n");
			while (resultSet.next()) {
				
				String customerType = resultSet.getString("CustomerType");
				String orderMonth = resultSet.getString("OrderMonth");
				Double totalOrderPrice = resultSet.getDouble("TotalOrderPrice");
				Double totalOrderCost = resultSet.getDouble("TotalOrderCost");
				Double profit = resultSet.getDouble("Profit");
				System.out.printf("%-15s | %-15s | %-18s| %-18s| %-8s%n", customerType, orderMonth, totalOrderPrice,
				    totalOrderCost, profit);
				
			}
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void updateDineIn(Integer orderId, Integer tableNumber) {
		try {
			String insertStatement = "INSERT INTO dinein" + "(DineInOrderID,DineInTableNumber) " + "VALUES (?, ?)";
			
			connect_to_db();
			
			PreparedStatement preparedStatement = conn.prepareStatement(insertStatement);
			
			preparedStatement.setInt(1, orderId);
			preparedStatement.setInt(2, tableNumber);
			preparedStatement.executeUpdate();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void updateDelivery(Integer orderId, String customerPhone, String customerEmail, String customerAddress, String customerState, String customerZipCode) {
		try {
			String insertStatement = "INSERT INTO delivery" + "(DeliveryOrderID,DeliveryCustomerPhone,DeliveryCustomerEmail,DeliveryCustomerAddress,DeliveryState,DeliveryZipCode) " + 
		"VALUES (?, ?, ?, ?, ?, ?)";
			
			connect_to_db();
			
			PreparedStatement preparedStatement = conn.prepareStatement(insertStatement);
			
			preparedStatement.setInt(1, orderId);
			preparedStatement.setString(2, customerPhone);
			preparedStatement.setString(3, customerEmail);
			preparedStatement.setString(4, customerAddress);
			preparedStatement.setString(5, customerState);
			preparedStatement.setString(6, customerZipCode);
			preparedStatement.executeUpdate();
			conn.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	public static void updatePickUp(Integer orderId) {
		try {
			String insertStatement = "INSERT INTO pickup" + "(PickUpOrderID) "  + "VALUES (?)";
			
			connect_to_db();
			
			PreparedStatement preparedStatement = conn.prepareStatement(insertStatement);
			
			preparedStatement.setInt(1, orderId);
			preparedStatement.executeUpdate();
			conn.close();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			}
			catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
	}
	
}
