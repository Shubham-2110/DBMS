package cpsc4620;


public class Constants {
	
	public static class OrderType {
		
		
		public  static String PICK_UP = "pickup";
		
		public static  String DINE_IN = "dinein";
		
		public  static String DELIVERY = "delivery";
		
	}
	
	public static class PizzaSize{
		
		public  static String SMALL = "small";
		
		public  static String MEDIUM = "medium";
		
		public static String LARGE = "large";
		
		public static String EXTRA_LARGE = "x-large";
	}
	
	public static class PizzaCrust {
		
		public  static String THIN = "Thin";
		
		public  static String ORIGINAL = "Original";
		
		public  static String GLUTEN_FREE = "Gluten-Free";
		
		public  static String PAN = "Pan";
	}
	
}
