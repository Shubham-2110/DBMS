package cpsc4620;

public class DeliveryOrder extends Order
{
	
	
	private int DeliveryOrderID;
	private String DeliveryCustomerPhone;
	private String DeliveryCustomerEmail;
	private String DeliveryCustomerAddress;
	private String DeliveryState;
	private String DeliveryZipCode;
	
	
	public int getDeliveryOrderID() {
		return DeliveryOrderID;
	}
	
	public String getDeliveryCustomerPhone() {
		return DeliveryCustomerPhone;
	}
	
	public String getDeliveryCustomerEmail() {
		return DeliveryCustomerEmail;
	}
	
	public String getDeliveryCustomerAddress() {
		return DeliveryCustomerAddress;
	}
	
	public String getDeliveryState() {
		return DeliveryState;
	}
	public String getDeliveryZipCode() {
		return DeliveryZipCode;
	}

	public void setDeliveryOrderID(int deliveryOrderID) {
		DeliveryOrderID = deliveryOrderID;
	}
	
	public void setDeliveryCustomerPhone(String deliveryCustomerPhone) {
		DeliveryCustomerPhone = deliveryCustomerPhone;
	}
	
	public void setDeliveryCustomerEmail(String deliveryCustomerEmail) {
		DeliveryCustomerEmail = deliveryCustomerEmail;
	}
	
	public void setDeliveryCustomerAddress(String deliveryCustomerAddress) {
		DeliveryCustomerAddress = deliveryCustomerAddress;
	}
	
	public void setDeliveryState(String deliveryState) {
		DeliveryState = deliveryState;
	}
	
	public void setDeliveryZipCode(String deliveryZipCode) {
		DeliveryZipCode = deliveryZipCode;
	}

	@Override
	public String toString() {
		return super.toString() + " | Delivered to: " + DeliveryCustomerAddress + "," + DeliveryState + "," + DeliveryZipCode;
	}
	
	
}
